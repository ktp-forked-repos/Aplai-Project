#!/bin/bash

sh experiment_VP3_FF_ID.sh > VP3_FF_ID.txt
sh experiment_VP3_LD_DMax.sh > VP3_LD_DMax.txt
sh experiment_VP3_LD_DMin.sh > VP3_LD_DMin.txt
sh experiment_VP3_SD_DMax.sh > VP3_SD_DMax.txt
sh experiment_VP3_SD_DMin.sh > VP3_SD_DMin.txt
