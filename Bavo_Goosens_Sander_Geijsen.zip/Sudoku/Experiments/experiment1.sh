#!/bin/bash

sh experiment_VP1_FF_ID.sh > VP1_FF_ID.txt
sh experiment_VP1_LD_DMax.sh > VP1_LD_DMax.txt
sh experiment_VP1_LD_DMin.sh > VP1_LD_DMin.txt
sh experiment_VP1_SD_DMax.sh > VP1_SD_DMax.txt
sh experiment_VP1_SD_DMin.sh > VP1_SD_DMin.txt
