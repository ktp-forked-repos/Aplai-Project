run Sudoku programs ECLiPSe

1) start eclipse and compile sudex_toledo.pl and the viewpoint you want to use
2) run commannd puzzles(P,'puzzlename'),solve(P).

run Sudoku programs CHR

1) start swipl and compile sudex_toledo.pl and the viewpoint you want to use
2) run commannd puzzles(P,'puzzlename'),solve(P).

run Battleship programs ECLiPSe

1) start eclipse and compile the problem files and the battleship_solitaire.ecl file
2) run commannd problem('problemnumber',X,Y,Z),solve(X,Y,Z,Sol).
