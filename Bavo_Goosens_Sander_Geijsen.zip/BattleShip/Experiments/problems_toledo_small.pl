% 2 Solutions for this problem.
problem( 15, [(2,6,water) ],
 			[0, 1, 1, 0, 4, 5, 1, 1, 2, 5] ,
 			[2, 0, 3, 1, 2, 2, 4, 1, 2, 3] ).

% 2 Solutions for this problem.
problem( 17, [ (6,3,water) ],
 			[0, 0, 2, 6, 2, 2, 3, 4, 0, 1] ,
 			[4, 2, 2, 1, 1, 4, 0, 2, 3, 1] ).

% 11 Solutions for this problem.
problem( 41, [ (4,1,water) ],
 			[4, 3, 6, 2, 4, 0, 1, 0, 0, 0] ,
 			[3, 0, 4, 1, 2, 1, 3, 2, 1, 3] ).

% 1 Solutions for this problem.
% 2535 Solutions for this problem.
problem( 42, [ (5,8,circle), (5,2,top) ],
 			[5, 1, 4, 1, 4, 1, 0, 0, 3, 1] ,
 			[1, 2, 1, 3, 2, 3, 3, 2, 2, 1] ).

% 6 Solutions for this problem.
problem( 61, [ (7,10,water), (2,1,water) ],
 			[0, 4, 4, 0, 5, 3, 2, 2, 0, 0] ,
 			[3, 2, 1, 2, 2, 2, 2, 3, 2, 1] ).

% 4 Solutions for this problem.
problem( 62, [ (3,3,water) ],
 			[1, 0, 2, 1, 0, 3, 4, 3, 1, 5] ,
 			[0, 2, 3, 3, 3, 1, 3, 2, 3, 0] ).

% 2 Solutions for this problem.
problem( 67, [ (5,1,water) ],
 			[0, 3, 5, 5, 1, 3, 2, 0, 1, 0] ,
 			[4, 1, 4, 0, 3, 1, 3, 0, 4, 0] ).

% 8 Solutions for this problem.
problem( 68, [ (7,5,water) ],
 			[0, 1, 4, 2, 4, 3, 3, 1, 1, 1] ,
 			[1, 6, 1, 0, 4, 0, 2, 3, 1, 2] ).

% 5 Solutions for this problem.
problem( 70, [ (5,8,water) ],
 			[3, 1, 6, 1, 4, 3, 2, 0, 0, 0] ,
 			[2, 2, 1, 2, 1, 2, 4, 2, 3, 1] ).

% 12 Solutions for this problem.
problem( 102, [ (10,6,circle) ],
 			[1, 0, 0, 1, 4, 0, 1, 6, 1, 6] ,
 			[5, 0, 3, 1, 0, 3, 1, 3, 2, 2] ).

% 10 Solutions for this problem.
problem( 112, [ (7,3,water) ],
 			[4, 0, 0, 1, 1, 0, 3, 4, 2, 5] ,
 			[4, 1, 4, 3, 1, 4, 1, 1, 0, 1] ).

% 7 Solutions for this problem.
problem( 118, [ (5,3,water) ],
 			[2, 0, 0, 0, 4, 4, 2, 2, 5, 1] ,
 			[2, 3, 2, 3, 2, 2, 1, 1, 3, 1] ).

% 8 Solutions for this problem.
problem( 133, [ (4,5,circle) ],
 			[0, 1, 0, 1, 1, 3, 4, 3, 3, 4] ,
 			[2, 2, 1, 3, 2, 1, 4, 2, 3, 0] ).

% 4 Solutions for this problem.
problem( 161, [ (4,1,water), (7,10,water) ],
 			[0, 0, 4, 4, 2, 5, 1, 2, 2, 0] ,
 			[2, 1, 1, 2, 1, 3, 3, 1, 3, 3] ).

% 7 Solutions for this problem.
problem( 173, [ (4,6,water) ],
 			[0, 0, 1, 4, 3, 5, 3, 3, 1, 0] ,
 			[4, 0, 3, 2, 2, 2, 0, 4, 1, 2] ).

% 1 Solutions for this problem.
% 535 Solutions for this problem.
problem( 177, [ (5,9,circle), (3,5,water) ],
 			[2, 0, 5, 1, 3, 3, 2, 4, 0, 0] ,
 			[2, 2, 2, 1, 4, 2, 1, 2, 2, 2] ).

% 9 Solutions for this problem.
problem( 182, [ (2,7,water) ],
 			[0, 3, 3, 1, 1, 2, 1, 1, 4, 4] ,
 			[1, 1, 2, 1, 1, 3, 3, 2, 5, 1] ).

% 2 Solutions for this problem.
problem( 187, [ (2,1,water) ],
 			[0, 2, 6, 1, 4, 3, 0, 1, 3, 0] ,
 			[3, 3, 1, 2, 1, 2, 1, 2, 4, 1] ).

% 6 Solutions for this problem.
problem( 189, [ (5,6,water) ],
 			[1, 2, 0, 4, 5, 1, 4, 3, 0, 0] ,
 			[2, 2, 2, 3, 1, 3, 2, 1, 2, 2] ).

% 4 Solutions for this problem.
problem( 204, [ (8,1,water) ],
 			[2, 2, 5, 2, 1, 1, 0, 3, 4, 0] ,
 			[3, 4, 1, 1, 4, 0, 4, 1, 1, 1] ).

% 2 Solutions for this problem.
problem( 222, [ (5,4,water) ],
 			[1, 6, 2, 3, 5, 1, 0, 0, 0, 2] ,
 			[3, 1, 1, 1, 4, 1, 3, 2, 1, 3] ).

% 13 Solutions for this problem.
problem( 233, [ (4,2,middle) ],
 			[1, 0, 2, 2, 4, 1, 5, 1, 0, 4] ,
 			[1, 4, 1, 1, 5, 0, 1, 1, 0, 6] ).

% 13 Solutions for this problem.
problem( 271, [ (9,5,water) ],
 			[1, 1, 1, 2, 4, 3, 1, 0, 5, 2] ,
 			[2, 5, 2, 3, 2, 1, 0, 2, 1, 2] ).

% 6 Solutions for this problem.
problem( 280, [ (3,5,water), (9,6,water) ],
 			[6, 1, 1, 1, 4, 4, 1, 0, 1, 1] ,
 			[3, 0, 5, 2, 3, 2, 1, 2, 2, 0] ).

% 4 Solutions for this problem.
problem( 281, [ (3,1,water), (9,7,water) ],
 			[1, 0, 5, 1, 3, 2, 0, 0, 4, 4] ,
 			[3, 2, 1, 2, 3, 4, 1, 2, 2, 0] ).

% 3 Solutions for this problem.
problem( 284, [ (2,1,water) ],
 			[0, 1, 0, 0, 4, 4, 3, 4, 2, 2] ,
 			[5, 0, 1, 2, 1, 3, 1, 1, 4, 2] ).
