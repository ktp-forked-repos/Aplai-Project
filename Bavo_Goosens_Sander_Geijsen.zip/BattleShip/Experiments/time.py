import monoclock

t = monoclock.nano_count()
t = t/1000000 
print t
